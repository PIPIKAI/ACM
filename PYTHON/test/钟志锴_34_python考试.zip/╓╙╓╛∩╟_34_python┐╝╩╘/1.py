#utf -8
for i in range(1,100000):
	if str(i) == str(i)[::-1]:
		print i
raw_input()